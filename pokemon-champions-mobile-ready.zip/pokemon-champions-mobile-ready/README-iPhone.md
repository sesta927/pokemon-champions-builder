# iPhoneで使うための公開手順

ChatGPTの添付ファイル表示はJavaScriptを実行しない場合があるため、添付HTMLを直接開いても操作できません。以下のフォルダを静的Webサイトとして公開してください。

## 方法A：GitHub Pages（iPhoneだけでも設定可能）

1. GitHubで新しい公開リポジトリを作成します。
2. このフォルダ内の `index.html`、`manifest.webmanifest`、`sw.js` をリポジトリ直下へアップロードします。
3. リポジトリの `Settings` → `Pages` を開きます。
4. `Source` を `Deploy from a branch` にします。
5. Branchを `main`、Folderを `/(root)` にして保存します。
6. Pages画面に表示された公開URLをSafariで開きます。
7. Safariの共有メニューから「ホーム画面に追加」を選択します。

## 方法B：Netlify Drop（PCからの公開が簡単）

1. このフォルダまたはZIPをNetlify Dropへアップロードします。
2. 発行された `netlify.app` のURLをiPhoneのSafariで開きます。
3. Safariの共有メニューから「ホーム画面に追加」を選択します。

## 起動確認

正常なURLで開くと、画面上部に一時的に「アプリ起動済み」と表示されます。警告表示が残り続ける場合、その表示環境ではJavaScriptが動いていません。
